package com.wasabi.store

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay

val DarkRed = Color(0xFF8B0000)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = lightColorScheme(
                        primary = DarkRed, onPrimary = Color.White,
                        secondaryContainer = Color(0xFFF3D6D6), onSecondaryContainer = DarkRed
                    )
                ) {
                    val vm: StoreVM = viewModel()
                    var splash by remember { mutableStateOf(true) }
                    LaunchedEffect(Unit) { delay(1800); splash = false }
                    if (splash) Splash() else StoreScreen(vm)
                }
            }
        }
    }
}

@Composable
fun Splash() {
    Column(
        Modifier.fillMaxSize().background(DarkRed),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painterResource(R.drawable.logo), null,
            Modifier.size(200.dp).clip(CircleShape),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.height(20.dp))
        Text(STORE_NAME, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreScreen(vm: StoreVM) {
    var showCheckout by remember { mutableStateOf(false) }
    val categories = listOf("الكل") + vm.products.map { it.category }.distinct()
    val shown = vm.products.filter {
        (vm.category == "الكل" || it.category == vm.category) &&
            it.name.contains(vm.query.trim(), ignoreCase = true)
    }

    Scaffold(
        topBar = {
            Column(Modifier.fillMaxWidth().background(DarkRed).padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painterResource(R.drawable.logo), null,
                        Modifier.size(44.dp).clip(CircleShape), contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        STORE_NAME, color = Color.White, fontSize = 20.sp,
                        fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { vm.refresh() }) { Text("تحديث", color = Color.White) }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = vm.query, onValueChange = { vm.query = it },
                    placeholder = { Text("ابحث عن منتج") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White, unfocusedContainerColor = Color.White
                    )
                )
            }
        },
        bottomBar = {
            if (vm.count > 0) {
                Row(
                    Modifier.fillMaxWidth().background(DarkRed).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("${vm.count} منتج", color = Color.White)
                        Text(
                            "الإجمالي: ${fmt(vm.total)} $CURRENCY",
                            color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp
                        )
                    }
                    Button(
                        onClick = { showCheckout = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = DarkRed)
                    ) { Text("إرسال الطلب", fontWeight = FontWeight.Bold) }
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { c ->
                    FilterChip(selected = vm.category == c, onClick = { vm.category = c }, label = { Text(c) })
                }
            }
            if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = DarkRed)
            vm.status?.let { Text(it, Modifier.padding(horizontal = 12.dp), color = DarkRed, fontSize = 13.sp) }
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(shown) { p -> ProductRow(vm, p) }
            }
        }
    }

    if (showCheckout) CheckoutDialog(vm) { showCheckout = false }
}

@Composable
fun ProductRow(vm: StoreVM, p: Product) {
    val q = vm.cart[p.name] ?: 0
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                if (p.price > 0) Text("${fmt(p.price)} $CURRENCY", color = DarkRed)
            }
            if (q == 0) {
                Button(onClick = { vm.add(p) }) { Text("إضافة") }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = { vm.remove(p) },
                        contentPadding = PaddingValues(0.dp), modifier = Modifier.size(38.dp)
                    ) { Text("−", fontSize = 20.sp) }
                    Text("$q", Modifier.padding(horizontal = 14.dp), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Button(
                        onClick = { vm.add(p) },
                        contentPadding = PaddingValues(0.dp), modifier = Modifier.size(38.dp)
                    ) { Text("+", fontSize = 20.sp) }
                }
            }
        }
    }
}

@Composable
fun CheckoutDialog(vm: StoreVM, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تأكيد الطلب") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = vm.custName, onValueChange = { vm.custName = it },
                    label = { Text("الاسم") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = vm.custAddress, onValueChange = { vm.custAddress = it },
                    label = { Text("العنوان / الحي") }, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFF5F5F5)).padding(10.dp)
                ) { Text(vm.buildMessage(), fontSize = 13.sp) }
                TextButton(onClick = { vm.clear(); onDismiss() }) { Text("تفريغ السلة", color = DarkRed) }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { vm.saveCustomer(); sendSms(ctx, vm.buildMessage()) }) { Text("رسالة نصية") }
                Button(onClick = { vm.saveCustomer(); sendWhatsApp(ctx, vm.buildMessage()) }) { Text("واتساب") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

fun sendWhatsApp(ctx: Context, msg: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$WA_NUMBER?text=" + Uri.encode(msg))))
    } catch (e: Exception) {
        Toast.makeText(ctx, "تعذّر فتح واتساب", Toast.LENGTH_SHORT).show()
    }
}

fun sendSms(ctx: Context, msg: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$STORE_PHONE")).putExtra("sms_body", msg))
    } catch (e: Exception) {
        Toast.makeText(ctx, "تعذّر فتح الرسائل", Toast.LENGTH_SHORT).show()
    }
}
