package com.wasabi.store

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

const val STORE_NAME = "تموينات الوصابي"
const val STORE_PHONE = "777114110"
const val WA_NUMBER = "967777114110"   // رقم المتجر بمفتاح اليمن
const val CURRENCY = "ريال"

fun fmt(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else "%.2f".format(v)

class StoreVM(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("store", Context.MODE_PRIVATE)
    private val sheetUrl: String = try {
        app.assets.open("sheet_url.txt").bufferedReader().readText().trim()
    } catch (e: Exception) { "" }

    var products by mutableStateOf(Catalog.sample)
    var loading by mutableStateOf(false)
    var status by mutableStateOf<String?>(null)
    var query by mutableStateOf("")
    var category by mutableStateOf("الكل")
    val cart = mutableStateMapOf<String, Int>()
    var custName by mutableStateOf(prefs.getString("name", "") ?: "")
    var custAddress by mutableStateOf(prefs.getString("address", "") ?: "")

    val count: Int get() = cart.values.sum()
    val total: Double get() = products.sumOf { (cart[it.name] ?: 0) * it.price }

    init {
        if (sheetUrl.isNotEmpty()) {
            prefs.getString("csv", null)?.let {
                val list = Catalog.toProducts(it)
                if (list.isNotEmpty()) products = list
            }
            refresh()
        }
    }

    fun refresh() {
        if (sheetUrl.isEmpty()) return
        viewModelScope.launch {
            loading = true
            try {
                val csv = withContext(Dispatchers.IO) {
                    val c = URL(sheetUrl).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000
                    c.readTimeout = 15000
                    c.instanceFollowRedirects = true
                    c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                }
                val list = Catalog.toProducts(csv)
                if (list.isNotEmpty()) {
                    products = list
                    prefs.edit().putString("csv", csv).apply()
                    val names = list.map { it.name }.toSet()
                    cart.keys.toList().forEach { if (it !in names) cart.remove(it) }
                    status = null
                } else status = "قائمة المنتجات فارغة"
            } catch (e: Exception) {
                status = "تعذّر تحديث المنتجات، يتم عرض آخر قائمة محفوظة"
            }
            loading = false
        }
    }

    fun add(p: Product) { cart[p.name] = (cart[p.name] ?: 0) + 1 }
    fun remove(p: Product) {
        val q = (cart[p.name] ?: 0) - 1
        if (q <= 0) cart.remove(p.name) else cart[p.name] = q
    }
    fun clear() = cart.clear()

    fun saveCustomer() {
        prefs.edit().putString("name", custName).putString("address", custAddress).apply()
    }

    fun buildMessage(): String {
        val sb = StringBuilder()
        sb.appendLine("طلب جديد - $STORE_NAME")
        if (custName.isNotBlank()) sb.appendLine("الاسم: ${custName.trim()}")
        if (custAddress.isNotBlank()) sb.appendLine("العنوان: ${custAddress.trim()}")
        sb.appendLine("----------")
        var n = 1
        products.filter { (cart[it.name] ?: 0) > 0 }.forEach { p ->
            val q = cart[p.name] ?: 0
            val line = if (p.price > 0) " = ${fmt(p.price * q)}" else ""
            sb.appendLine("${n++}) ${p.name} × $q$line")
        }
        sb.appendLine("----------")
        sb.append("الإجمالي: ${fmt(total)} $CURRENCY")
        return sb.toString()
    }
}
