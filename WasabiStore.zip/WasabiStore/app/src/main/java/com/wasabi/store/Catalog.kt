package com.wasabi.store

data class Product(val name: String, val price: Double, val category: String)

object Catalog {
    // منتجات تجريبية تظهر إلى أن يتم ربط التطبيق بقائمة المنتجات الحقيقية
    val sample = listOf(
        Product("رز بسمتي 5 كجم", 5500.0, "مواد غذائية"),
        Product("سكر 5 كجم", 4000.0, "مواد غذائية"),
        Product("دقيق 5 كجم", 3500.0, "مواد غذائية"),
        Product("زيت 1.5 لتر", 2500.0, "مواد غذائية"),
        Product("شاي 400 جم", 2000.0, "مشروبات"),
        Product("حليب بودرة 900 جم", 4500.0, "مشروبات"),
        Product("مياه شرب كرتون", 1500.0, "مشروبات"),
        Product("معكرونة", 500.0, "مواد غذائية"),
        Product("صابون غسيل", 800.0, "منظفات"),
        Product("منظف أطباق", 1200.0, "منظفات"),
    )

    private fun normalizeDigits(s: String): String = s.map {
        when (it) {
            in '٠'..'٩' -> '0' + (it - '٠')
            '٫', '،' -> '.'
            else -> it
        }
    }.joinToString("")

    fun parseCsv(text: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        val t = text.removePrefix("\uFEFF")
        var i = 0
        while (i < t.length) {
            val c = t[i]
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < t.length && t[i + 1] == '"') { sb.append('"'); i++ } else inQuotes = false
                } else sb.append(c)
            } else when (c) {
                '"' -> inQuotes = true
                ',' -> { row.add(sb.toString().trim()); sb.clear() }
                '\n' -> { row.add(sb.toString().trim()); sb.clear(); rows.add(row); row = mutableListOf() }
                '\r' -> {}
                else -> sb.append(c)
            }
            i++
        }
        if (sb.isNotEmpty() || row.isNotEmpty()) { row.add(sb.toString().trim()); rows.add(row) }
        return rows
    }

    /** الأعمدة: الاسم، السعر، القسم (والصف الأول عناوين) */
    fun toProducts(csv: String): List<Product> =
        parseCsv(csv).drop(1).mapNotNull { r ->
            val name = r.getOrNull(0)?.trim().orEmpty()
            if (name.isEmpty()) return@mapNotNull null
            val price = normalizeDigits(r.getOrNull(1).orEmpty())
                .replace(Regex("[^0-9.]"), "").toDoubleOrNull() ?: 0.0
            val cat = r.getOrNull(2)?.trim().orEmpty().ifEmpty { "عام" }
            Product(name, price, cat)
        }
}
